#ifndef _wkup_H
#define _wkup_H

#include "system.h"


void Enter_Standby_Mode(void);

#endif
