#ifndef _led_H
#define _led_H

#include "stm32f4xx.h"


void LED_Init(void);


#endif
