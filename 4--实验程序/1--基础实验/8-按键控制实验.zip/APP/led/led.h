#ifndef _led_H
#define _led_H

#include "system.h"


#define LED1 PFout(9)
#define LED2 PFout(10)


void LED_Init(void);


#endif
