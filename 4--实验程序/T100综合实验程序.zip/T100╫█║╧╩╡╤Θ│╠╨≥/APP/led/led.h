#ifndef _led_H
#define _led_H

#include "system.h"

/*  LEDʱ�Ӷ˿ڡ����Ŷ��� */
#define LED0_PORT 			GPIOF   
#define LED0_PIN 			GPIO_Pin_9
#define LED0_PORT_RCC		RCC_AHB1Periph_GPIOF

#define LED1_PORT 			GPIOF   
#define LED1_PIN 			GPIO_Pin_10
#define LED1_PORT_RCC		RCC_AHB1Periph_GPIOF


#define LED0 PFout(9)  	
#define LED1 PFout(10)  	


void LED_Init(void);


#endif
